class mSort {
  constructor() {

  }
  static bubble(){

  }
  static selection (){

  }
  static insertion (){

  }
  static merge (){

  }
  static quick (){

  }
}
module.exports = mSort
