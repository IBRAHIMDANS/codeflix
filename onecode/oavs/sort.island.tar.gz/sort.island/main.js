const mSort = require('./m_sort');

 const arr = [1,2,3,4,5,6,7,8,9];

 console.log(mSort.bubble(arr));
 console.log(mSort.selection(arr));
 console.log(mSort.insertion(arr));
 console.log(mSort.merge(arr));
 console.log(mSort.quick(arr));
