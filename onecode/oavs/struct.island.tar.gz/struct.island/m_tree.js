const bNode = require('./m_binary_node');
class mTree {
  constructor() {
    this._root = null
  }
  getRoot(){
    return this.head
  }
  search(data){

  }
  insert(data){

  }
  remove(data){

  }
  inorder(){

  }
  deep(){

  }
  compare(tree){
    
  }
}
module.exports = mTree;
