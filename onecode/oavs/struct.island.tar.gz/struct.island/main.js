const mNode = require('./m_node');
const mLinkedList = require('./m_linked_list');

const node = new mLinkedList();

 node.push(5)
 node.push(6)
 node.push(8)
 node.push(9)
 node.push(4)
 node.push(2)
 node.push(1)

node.toString()
 console.log(node);
